#include <stdio.h>
#include <math.h>
int main()
{
    float a, b, c, d, root1, root2;
    printf("Enter the coefficients of the quadratic equation (a, b, c): "); // ax^2+bx+c
    scanf("%f %f %f", &a, &b, &c);
    d = b * b - 4 * a * c;//discriminent
    // nature of the roots
    if (d > 0)
    {
        root1 = (-b + sqrt(d)) / (2 * a);
        root2 = (-b - sqrt(d)) / (2 * a);
        printf("Roots are real and different.\n");
        printf("Root 1 = %.2f\n", root1);
        printf("Root 2 = %.2f\n", root2);
    }
    else if (d == 0)
    {
        root1 = root2 = -b / (2 * a);
        printf("Roots are real and equal.\n");
        printf("Root 1 = Root 2 = %.2f\n", root1);
    }
    else
    {
        float real = -b / (2 * a);//real part
        float img = sqrt(-d) / (2 * a);//imaginary
        printf("Roots are complex and different.\n");
        printf("Root 1 = %.2f + %.2fi\n", real, img);
        printf("Root 2 = %.2f - %.2fi\n", real, img);
    }
    return 0;
}
