#include <stdio.h>
int main()
{
    int num1, num2, num3;
    // Input three numbers
    printf("Enter three numbers: ");
    scanf("%d %d %d", &num1, &num2, &num3);
    // Without using ternary operators to find maximum and minimum
    int max, min;
    // For maximum
    if (num1 > num2 && num1 > num3)
        max = num1;
    else if (num2 > num3)
        max = num2;
    else
        max = num3;
    // For minimum
    if (num1 < num2 && num1 < num3)
        min = num1;
    else if (num2 < num3)
        min = num2;
    else
        min = num3;
    // Display the results
    printf("Maximum number: %d\n", max);
    printf("Minimum number: %d\n", min);
    return 0;
}
