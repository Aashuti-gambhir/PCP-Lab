#include <stdio.h>
int main()
{
    int marks1, marks2, marks3, marks4, marks5, total_marks;
    float percentage;
    printf("Enter marks for five subjects:\n");
    printf("Subject 1: ");
    scanf("%d", &marks1);
    printf("Subject 2: ");
    scanf("%d", &marks2);
    printf("Subject 3: ");
    scanf("%d", &marks3);
    printf("Subject 4: ");
    scanf("%d", &marks4);
    printf("Subject 5: ");
    scanf("%d", &marks5);
    // Valid marks (marks need to be between 0 and 100)
    if (marks1 < 0 || marks1 > 100 || marks2 < 0 || marks2 > 100 || marks3 < 0 || marks3 > 100 ||
        marks4 < 0 || marks4 > 100 || marks5 < 0 || marks5 > 100)
    {
        printf("Invalid marks! Marks should be between 0 and 100.\n");
        return 1; // Exit the program with error
    }
    // Calculate
    total_marks = marks1 + marks2 + marks3 + marks4 + marks5;
    percentage = (float)total_marks / 5;
    printf("Percentage: %.2f%%\n", percentage);
    // grade
    if (percentage >= 90)
    {
        printf("Grade: A\n");
    }
    else if (percentage >= 80)
    {
        printf("Grade: B\n");
    }
    else if (percentage >= 70)
    {
        printf("Grade: C\n");
    }
    else if (percentage >= 60)
    {
        printf("Grade: D\n");
    }
    else if (percentage >= 40)
    {
        printf("Grade: E\n");
    }
    else
    {
        printf("Grade: Fail\n");
    }
    return 0;
}
