#include <stdio.h>

int main()
{
    int num1, num2, num3;

    // Input of three numbers
    printf("Enter three numbers: ");
    scanf("%d %d %d", &num1, &num2, &num3);

    // Using ternary operators to find maximum and minimum
    int max = (num1 > num2) ? ((num1 > num3) ? num1 : num3) : ((num2 > num3) ? num2 : num3);
    int min = (num1 < num2) ? ((num1 < num3) ? num1 : num3) : ((num2 < num3) ? num2 : num3);
    printf("Maximum number: %d\n", max);
    printf("Minimum number: %d\n", min);

    return 0;
}