#include<stdio.h>
void intro(){
printf("I am AASHUTI ");
}
int main(){
    intro();
    return 0;
}