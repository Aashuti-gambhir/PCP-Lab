#include<stdio.h>
int main(){
    int num1;
    printf("enter 1st number :");
    scanf("%d",&num1);
    int num2;
    printf("enter 2nd number :");
    scanf("%d",&num2);
    int *ptr1=&num1;
    int *ptr2=&num2;
    int temp=*ptr1;
    *ptr1=*ptr2;
    *ptr2=temp;
    printf("After swaping,\n1st number is %d and 2nd number is %d",*ptr1,*ptr2);
    return 0;
}