#include<stdio.h>
int sum(int arr[100],int num)
{
    int sum=0;
    for(int i=0;i<num;i++)
    {
        sum=sum+arr[i];
    }
    return sum;
}
int main(){
    int arr[100],num;
    printf("number of elements in array : ");
    scanf("%d",&num);
    for(int i=0;i<num;i++)
    {
        printf("enter %dth number :",i+1);
        scanf("%d",&arr[i]);
    }
    printf("sum of array : %d",sum(arr,num));
    return 0;
}