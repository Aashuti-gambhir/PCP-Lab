#include<stdio.h>
int main(){
    int num1;
    printf("enter 1st number :");
    scanf("%d",&num1);
    int num2;
    printf("enter 2st number :");
    scanf("%d",&num2);
    int *ptr1=&num1;
    int *ptr2=&num2;
    int sum=*ptr1+*ptr2;
    printf("%d",sum);
    return 0;
}