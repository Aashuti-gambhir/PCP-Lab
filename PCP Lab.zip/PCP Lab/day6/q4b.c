#include<stdio.h>
int sum(int a,int b){
return a+b;
}
int main(){
    int num1;
    printf("enter 1st number :");
    scanf("%d",&num1);
    int num2;
    printf("enter 2nd number :");
    scanf("%d",&num2);
    int result=sum(num1,num2);
    printf("%d",result);
    return 0;
}