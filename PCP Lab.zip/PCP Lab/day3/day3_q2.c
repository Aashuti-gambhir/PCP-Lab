#include <stdio.h>
int main()
{
    int num, divisible, sum = 0,i;
    printf("enter a number : ");
    scanf("%d", &num);
    for (i = 2; i <= num; i++)
    {
        divisible = i % 30;
        if (divisible == 0)
        sum = sum + i;
    }
    printf("sum of all numbers divisible by 2,3 and 5 under %d is : %d", num, sum);
    return 0;
}