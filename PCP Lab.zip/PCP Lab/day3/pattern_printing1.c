#include<stdio.h>
int main(){
    int row,i,j,temp=0,k,l;
    printf("enter number of rows : ");
    scanf("%d",&row);
    for(i=0;i<row;i++)
    {
        for(j=0;j<=i;j++)
        {
            printf("* ");
        }
        printf("\n");
    }
    for(i=row;i<2*row;i++)
    {
        temp++;
        for(k=row-temp;k>0;k--)
        {
            printf("* ");
        } 
        printf("\n"); 
    }
        
    return 0;
}