#include <stdio.h>
int main()
{
    int row, i, j, k, l;
    printf("enter number of rows : ");
    scanf("%d", &row);
    for (i = 0; i < row; i++)
    {
        for (k = 0; k < row - i; k++)
        {
            printf("  ");
        }
        for (j = row - i; j <= row + i; j++)
            printf("%d ", i+1);
        printf("\n");
    }
    return 0;
}