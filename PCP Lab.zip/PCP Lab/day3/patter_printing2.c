#include<stdio.h>
int main(){
    int row,i,j,k,l;
    printf("enter number of rows : ");
    scanf("%d",&row);
    for(i=0;i<=row;i++)
    {
        for(j=0;j<row-i;j++)
        {
            printf("  ");
        }
        for(k=row-i;k<row-1;k++)
        {
            printf("%d ",row-k-1);
        }
        for(l=0;l<i;l++)
        {
            printf("%d ",l);
        }
        printf("\n");
    }
    return 0;
}
/*enter number of rows : 6

          0
        1 0 1
      2 1 0 1 2
    3 2 1 0 1 2 3
  4 3 2 1 0 1 2 3 4
5 4 3 2 1 0 1 2 3 4 5*/