#include<stdio.h>
int main(){
    int num,count=0;
    printf("enter a number: ");
    scanf("%d",&num);
    for(int i=2;i*i<num;i++)
    {
        if (num%i == 0)
        {
            printf("The number is composite.");
            return 0;
        }
        
    }
    printf("The number is prime.");
    return 0;
}