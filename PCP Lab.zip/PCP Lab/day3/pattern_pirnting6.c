#include<stdio.h>
int main()
{
    int row,i,j,k;
    printf("enter number of rows : ");
    scanf("%d",&row);
    for(i=0;i<row;i++)
    {
        for(j=0;j<row-i-1;j++)
        printf(" ");
    
    for(k=0;k<=i;k++)
    printf("%d ",i+1);
    printf("\n");
    }
    return 0;
}