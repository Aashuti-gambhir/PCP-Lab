#include<stdio.h>
int main()
{
    int row,i,j,k;
    printf("enter number of rows : ");
    scanf("%d",&row);
    for(i=1;i<=row;i++)
    {
        for(j=0;j<row-i;j++)
        {
            printf("  ");
        }
        for(k=0;k<i;k++)
        {
            printf("%d ",i);
        }
        printf("\n");
    }
    return 0;
}