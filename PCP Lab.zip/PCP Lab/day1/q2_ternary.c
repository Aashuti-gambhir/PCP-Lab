#include<stdio.h>
int main()
{
    int num1,num2;
    printf("enter 1st number: ");//type number 
    scanf("%d",&num1);
    printf("enter 2nd number: ");
    scanf("%d",&num2);
    //with ternary operator
    int temp;
    temp=num1;
    num1=num2;
    num2=temp;
    printf("after reversing,\n1st number= %d\n2nd number= %d",num1,num2);
    return 0;
}