#include<stdio.h>
int main(){
    int basic_salary,dearness=40,house_rent=20;
    printf("basic salary of ramesh is: ");
    scanf("%d",&basic_salary);
    float gross_salary=basic_salary*(1+(float)dearness/100+(float)house_rent/100);
    printf("gross salary: %.2f",gross_salary);
    return 0;
}