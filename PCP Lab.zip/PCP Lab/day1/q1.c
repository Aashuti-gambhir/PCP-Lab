#include <stdio.h>
int main()
{
    int num1 = 20, num2 = 10;
    int sum = num1 + num2;
    int multi = num1 * num2;
    int sub = num1 - num2;
    float division = num1 / num2;
    int modulo = num1 % num2;
    printf("sum : %d\n", sum);
    printf("multiplication : %d\n", multi);
    printf("substraction : %d\n", sub);
    printf("division : %.2f\n", division);
    printf("modulo : %d", modulo);

    return 0;
}
