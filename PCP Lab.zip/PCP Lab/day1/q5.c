#include<stdio.h>
int main(){
    int tempf;
    printf("enter temperature in fahrenheit: ");
    scanf("%d",&tempf);
    float tempc=(tempf-32)*(float)5/9;
    printf("temperature in celius: %.2f",tempc);
    return 0;
}