#include<stdio.h>
int main(){
    int num,hundred,fifty,ten;
    printf("enter amount: ");
    scanf("%d",&num);
    hundred=num/100;
    num=num-hundred*100;
    fifty=num/50;
    num=num-fifty*50;
    ten=num/10;
    num=num-ten*10;
    printf("currency note of 100: %d\ncurrency note of 50: %d\ncurrency note of 10: %d\ncurrency note of 1: %d",hundred,fifty,ten,num);
    return 0;
}