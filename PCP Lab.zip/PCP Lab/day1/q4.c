#include<stdio.h>
int main(){
    int a=60,b=70,c=80,d=85,e=75;
    float avg=(a+b+c+d+e)/5;
    printf("average=%.2f",avg);
    return 0;
}
