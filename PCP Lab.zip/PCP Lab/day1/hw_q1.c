#include <stdio.h>
int main()
{
    int num, sum;
    printf("enter 5 digit number: ");
    scanf("%d", &num);
    while (num != 0)
    {
        sum += num % 10;
        num /= 10;
    }
    printf("%d is sum of each digit", sum);
    return 0;
}