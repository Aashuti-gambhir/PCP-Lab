#include <stdio.h>
int main()
{
    int num1, num2;
    // Input two integers
    printf("Enter 1st number: ");
    scanf("%d", &num1);
    printf("Enter 2nd number: ");
    scanf("%d", &num2);
    // without using a temporary variable
    num1 = num1 + num2;
    num2 = num1 - num2;
    num1 = num1 - num2;
    // the swapped values
    printf("After swapping:\n");
    printf("1st number = %d\n", num1);
    printf("2nd number = %d\n", num2);
    return 0;
}
