#include<stdio.h>
#define PI 3.14159265359
#define AREA(radius) (PI*radius*radius)
int main(){
    float area,radius;
    printf("enter radius : ");
    scanf("%f",&radius);
    printf("%f",AREA(radius));
    return 0;
}