#include<stdio.h>
#define greater(a,b,c)(a>b&&a>c? a:(b>a&&b>c? b: c))
int main(){
    int a,b,c;
    printf("enter three numbers you want to compare : ");
    scanf("%d %d %d",&a,&b,&c);
    printf("%d",greater(a,b,c));
    return 0;
}