#include<stdio.h>
#define PI 3.14159265359
int main(){
    float area,radius;
    printf("enter radius : ");
    scanf("%f",&radius);
    printf("%f",PI*radius*radius);
    return 0;
}