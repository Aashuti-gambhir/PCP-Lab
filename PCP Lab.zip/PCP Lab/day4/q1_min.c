#include<stdio.h>

int main(){
    int min,num,arr[100],i;
    printf("how many numbers you want to compare?\n");
    scanf("%d",&num);
    for(i=0;i<num;i++)
    {
        printf("enter number %d : ",i+1);
        scanf("%d",&arr[i]);
    }
    min=arr[0];
    for(i=0;i<num;i++)
    {
        if(min>arr[i])
        min=arr[i];
    }
    printf("%d is minimum",min);
    return 0;
}