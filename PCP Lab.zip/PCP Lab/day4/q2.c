#include<stdio.h>
int main(){
    int arr[100],i,num;
    float sum=0;
    printf("of how many numbers you want average?\n");
    scanf("%d",&num);
    for(i=0;i<num;i++)
    {
        printf("enter number %d : ",i+1);
        scanf("%d",&arr[i]);
    }
    for(i=0;i<num;i++)
    sum=sum+arr[i];
    float dup=num;
    float avg=sum/dup;
    printf("%.2f is average",avg);
    return 0;
}