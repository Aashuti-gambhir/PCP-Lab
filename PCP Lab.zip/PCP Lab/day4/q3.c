#include<stdio.h>
int main(){
    int repeat=0,arr[10],i,j,num;
    for(i=0;i<10;i++)
    {
        printf("enter number %d : ",i+1);
        scanf("%d",&arr[i]);
    }
    printf("enter a number of which you want to find accurance : ");
    scanf("%d",&num);
    for(i=0;i<10;i++)
    {
        for(j=i;j<10;j++)
        {
            if(arr[i]==arr[j]&&arr[i]==num)
            repeat++;
        }
    }
    printf("%d is total number of accurance of %d",repeat,num);
    return 0;
}