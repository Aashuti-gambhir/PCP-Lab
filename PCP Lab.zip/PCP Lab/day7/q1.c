#include <stdio.h>
#include <math.h>
struct complex
{
    float real;
    float img;
} num1, num2, result;
struct complex sum(struct complex num1, struct complex num2)
{
    result.real = num1.real + num2.real;
    result.img = num1.img + num2.img;
    return result;
}
struct complex diff(struct complex num1, struct complex num2)
{
    result.real = num1.real - num2.real;
    result.img = num1.img - num2.img;
    return result;
}
float modulus(struct complex num1, struct complex num2)
{
    float mod = sqrt((num1.real * num1.real) + (num1.img * num1.img));
    return mod;
}
struct complex multi(struct complex num1, struct complex num2)
{
    result.real = num1.real * num2.real - num1.img * num2.img;
    result.img = num1.img * num2.real + num2.img * num1.real;
    return result;
}
int main()
{
    struct complex num1, num2, result;
    float mod;
    printf("enter num1's real part: ");
    scanf("%f", &num1.real);
    printf("enter num2's real part: ");
    scanf("%f", &num2.real);
    printf("enter num1's imaginary part: ");
    scanf("%f", &num1.img);
    printf("enter num2's imaginary part: ");
    scanf("%f", &num2.img);
    result = sum(num1, num2);
    printf("%.2f+%.2fi is sum of two complex num\n", result.real, result.img);
    result = diff(num1, num2);
    printf("%.2f+%.2fi is difference between two complex num\n", result.real, result.img);
    mod = modulus(num1, num2);
    printf("%.2fis mod of 1st number\n", mod);
    result = multi(num1, num2);
    printf("%.2f+%.2fi is multiplication of two complex num\n", result.real, result.img);
    return 0;
}