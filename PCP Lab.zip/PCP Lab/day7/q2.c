#include<stdio.h>
int fabo(int num){
    if(num==1)return 0;
    if(num==2) return 1;
    return fabo(num-1)+fabo(num-2);
}
int main(){
    int num;
    printf("enter a number : ");
    scanf("%d",&num);
    for(int i=1;i<=num;i++){
        printf("%d ",fabo(i));
    }
    return 0;
}