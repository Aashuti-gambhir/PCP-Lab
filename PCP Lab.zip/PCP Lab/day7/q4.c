#include<stdio.h>
int sum(int num){
    if(num==0) return 0;
    int rem=num%10;
    int result=rem+sum(num/10);
    return result;
}
int main(){
    int num;
    printf("enter a number: ");
    scanf("%d",&num);
    printf("sum of each digit of number : %d",sum(num));

    return 0;
}