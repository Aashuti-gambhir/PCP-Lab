#include<stdio.h>
int fact(int num){
    if(num==1) return 1;
    return fact(num-1)*num;
}
int main(){
    int num;
    printf("enter a number");
    scanf("%d",&num);
    printf("%d",fact(num));
    return 0;
}