#include <stdio.h>
int main()
{
    int rows, columns, mat[100][100];
    printf("enter number of rows and columns : ");
    scanf("%d%d", &rows, &columns);
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            printf("enter (%d,%d)th element : ", i + 1, j + 1);
            scanf("%d", &mat[i][j]);
        }
        printf("\n");
    }
    for (int i = 0; i <columns; i++)
    {
        for (int j = 0; j < rows; j++)
        {
            printf("%d ", mat[j][i]);
        }
        printf("\n");
    }
    return 0;
}