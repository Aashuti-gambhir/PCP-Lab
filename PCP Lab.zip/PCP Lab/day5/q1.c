#include <stdio.h>
int main()
{
    int rows, columns, mat[100][100], sum = 0, product = 1;
    printf("enter number of rows and columns : ");
    scanf("%d%d", &rows, &columns);
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            printf("enter (%d,%d)th element : ", i + 1, j + 1);
            scanf("%d", &mat[i][j]);
        }
        printf("\n");
    }
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }
    if (rows == columns)
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < columns; j++)
            {
                if (i == j)
                {
                    sum = sum + mat[i][j];
                    product = product * mat[i][j];
                }
            }
        }
        printf("\n\nsum of diagonal elements is : %d", sum);
        printf("\nproduct of diagonal elements is : %d", product);
    }
    else
    printf("sum and product of diagonal is possible only in square matrices");
    return 0;
}