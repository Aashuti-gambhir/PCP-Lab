#include <stdio.h>
int main()
{
    int rows, columns, mat[100][100],max,min;
    printf("enter number of rows and columns : ");
    scanf("%d%d", &rows, &columns);
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            printf("enter (%d,%d)th element : ", i + 1, j + 1);
            scanf("%d", &mat[i][j]);
        }
        printf("\n");
    }
    for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }
    max=mat[0][0];
    min=mat[0][0];
     for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            if(max<mat[i][j])
            max=mat[i][j];
        }
    }
     for (int i = 0; i < rows; i++)
    {
        for (int j = 0; j < columns; j++)
        {
            if(min>mat[i][j])
            min=mat[i][j];
        }
    }
    printf("\nmax number in matrix is : %d",max);
    printf("\nmin number in matrix is : %d",min);
return 0;
}