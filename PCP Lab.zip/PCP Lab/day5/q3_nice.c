#include <stdio.h>
#include <stdlib.h>
int main()
{
    int rows[100], columns[100], mat[100][100], num, sum[100][100] = {0}, count = 0;
    printf("How many matrices do you want to add ?\n");
    scanf("%d", &num);
    for (int k = 0; k < num; k++)
    {
        printf("for matrice %d :\n", k + 1);
        printf("enter number of rows and columns : \n");
        scanf("%d%d", &rows[k], &columns[k]);
        if (rows[k] != rows[0] || columns[k] != columns[0])
        {
            count++;
        }
    }
    for (int k = 0; k < num; k++)
    {
        if(count>0)
        {
            printf("sum of matrices is not compatible");
            exit(0); // after exit no need to apply else (my opinion)
        }
        printf("for matrice %d :\n", k + 1);
        for (int i = 0; i < rows[0]; i++)
        {
            for (int j = 0; j < columns[0]; j++) // here these column[k]  ->for different "k" there will bw same column[k] and row[k]
            {
                printf("enter (%d,%d)th element : ", i + 1, j + 1);
                scanf("%d", &mat[i][j]);
                sum[i][j] = sum[i][j] + mat[i][j];
            }
            printf("\n");
        }
    }
    printf("sum of all matrices is : \n");
    for (int i = 0; i < rows[0]; i++)
    {
        for (int j = 0; j < columns[0]; j++)
        {
            printf("%d ", sum[i][j]);
        }
        printf("\n");
    }
    return 0;
}